var searchData=
[
  ['orig_5fcerr_0',['orig_cerr',['../class_simulation_test.html#ad1c33dcd9360e6d5a6fdcbadb5aab455',1,'SimulationTest']]],
  ['orig_5fcout_1',['orig_cout',['../class_simulation_test.html#a6a4b47b030423ea35deb478ac8ecf077',1,'SimulationTest']]]
];
