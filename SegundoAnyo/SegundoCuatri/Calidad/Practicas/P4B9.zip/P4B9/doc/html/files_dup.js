var files_dup =
[
    [ "include", "dir_07a57ea6e72c59816851aa358fcaf4a9.html", "dir_07a57ea6e72c59816851aa358fcaf4a9" ],
    [ "PXB9", "dir_ec306c81fff0ba3a54b9fb94a7d56439.html", "dir_ec306c81fff0ba3a54b9fb94a7d56439" ],
    [ "src", "dir_a598cc68015d9a90cd8086c646f002a6.html", "dir_a598cc68015d9a90cd8086c646f002a6" ],
    [ "tests", "dir_5da26458a848650697e725a39e6cd592.html", "dir_5da26458a848650697e725a39e6cd592" ]
];