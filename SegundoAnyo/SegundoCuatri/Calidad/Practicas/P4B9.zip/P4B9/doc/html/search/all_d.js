var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['remove_1',['remove',['../class_lista_enlazada.html#ad62bf0979809fa4aaa070386d70109e9',1,'ListaEnlazada::remove()'],['../class_v_dinamico.html#aeebee56ad39c658aa59967007c50c1c7',1,'VDinamico::remove()']]],
  ['removefirst_2',['removeFirst',['../class_lista_enlazada.html#aebe57d7807ed5798aeafcc899cc8c65f',1,'ListaEnlazada']]],
  ['removelast_3',['removeLast',['../class_lista_enlazada.html#a27eb9552bfd786352c7f79f849fb4c52',1,'ListaEnlazada']]],
  ['roundtopowerof2_4',['roundToPowerOf2',['../class_v_dinamico.html#a67dbbc820be10b52be774ebeb8c0b0ce',1,'VDinamico']]],
  ['run_5fsimulation_5',['run_simulation',['../core__logic_8h.html#af8ecda9b56926116df4a91a7dbb5d06d',1,'run_simulation(const std::string &amp;medsPath=&quot;../data/pa_medicamentos.csv&quot;, const std::string &amp;labsPath=&quot;../data/laboratorios.csv&quot;):&#160;core_logic.cpp'],['../core__logic_8cpp.html#a8eb8e84380c497a113b6bfbd69359e77',1,'run_simulation(const std::string &amp;medsPath, const std::string &amp;labsPath):&#160;core_logic.cpp']]]
];
