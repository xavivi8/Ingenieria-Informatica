var searchData=
[
  ['allocatememory_0',['allocateMemory',['../class_v_dinamico.html#a8ee8794f2c826a2654cbc716700e2800',1,'VDinamico']]],
  ['autolinkmedications_1',['autoLinkMedications',['../class_medi_express.html#a2592fd9cb8fb6d700dcd93b05cc155a8',1,'MediExpress']]]
];
