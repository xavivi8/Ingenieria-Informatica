var searchData=
[
  ['safe_5fread_0',['safe_read',['../core__logic_8h.html#a732c786b6d8cff35c8d1b4f3be02f787',1,'safe_read(unsigned int &amp;value):&#160;core_logic.cpp'],['../core__logic_8cpp.html#a732c786b6d8cff35c8d1b4f3be02f787',1,'safe_read(unsigned int &amp;value):&#160;core_logic.cpp']]],
  ['setaddress_1',['setAddress',['../class_laboratorio.html#aad3d7a774f4eec49eb7d8f33a8483d03',1,'Laboratorio']]],
  ['setcity_2',['setCity',['../class_laboratorio.html#a1102946ca2a1e85a8e719e14d941afe1',1,'Laboratorio']]],
  ['setid_3',['setId',['../class_laboratorio.html#a9f23aa743cf479084dc082b57cf89008',1,'Laboratorio']]],
  ['setidalpha_4',['setIdAlpha',['../class_pa_medicamento.html#a67d84d1d285e4fccccbf3b10ed5c4b32',1,'PaMedicamento']]],
  ['setidnum_5',['setIdNum',['../class_pa_medicamento.html#ab699a583c8fd3136326775ae758dd913',1,'PaMedicamento']]],
  ['setlabname_6',['setLabName',['../class_laboratorio.html#ad69e9d934f898392367e4b2028f78b00',1,'Laboratorio']]],
  ['setname_7',['setName',['../class_pa_medicamento.html#ae6dadd41c586ae27158fa94a414ede2a',1,'PaMedicamento']]],
  ['setpostalcode_8',['setPostalCode',['../class_laboratorio.html#a5ceb335191faccadd2461d89c273ffb1',1,'Laboratorio']]],
  ['setservidopor_9',['setServidoPor',['../class_pa_medicamento.html#abcc6a18b3481c64bff4bb458fdb3b44a',1,'PaMedicamento']]],
  ['setup_10',['SetUp',['../class_simulation_test.html#a868cdfc647571e6b0825b7a870752e86',1,'SimulationTest::SetUp() override'],['../class_simulation_test.html#a868cdfc647571e6b0825b7a870752e86',1,'SimulationTest::SetUp() override']]],
  ['simulationtest_11',['SimulationTest',['../class_simulation_test.html',1,'']]],
  ['size_12',['size',['../class_lista_enlazada.html#a1ebb2d529992d71378e426d24eb9350e',1,'ListaEnlazada']]],
  ['sonarqube_13',['Warnings de SonarQube',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['sort_14',['sort',['../class_v_dinamico.html#ab3a3ba8f23acc9ca8c4be93d7135576e',1,'VDinamico']]],
  ['suministrarmed_15',['suministrarMed',['../class_medi_express.html#a10c0dec41b25a62023054ea486e8efe1',1,'MediExpress']]]
];
