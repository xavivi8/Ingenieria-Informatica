var class_laboratorio =
[
    [ "Laboratorio", "class_laboratorio.html#a203ae5fbf52d077614e3234456994b02", null ],
    [ "Laboratorio", "class_laboratorio.html#a9737b8bd3136153d126e5235912260a0", null ],
    [ "~Laboratorio", "class_laboratorio.html#ad5c1923ca87f121b607f3cd2656eed12", null ],
    [ "getAddress", "class_laboratorio.html#a095431d1a35295ceaee3e9b8aff5719b", null ],
    [ "getCity", "class_laboratorio.html#afc6701374dd84642cbcfab819eb1ff3e", null ],
    [ "getId", "class_laboratorio.html#ac70375c93c5763347712393450dc1a2b", null ],
    [ "getLabName", "class_laboratorio.html#a3ae1e03573efff0aeaa5e2e1ed978c47", null ],
    [ "getPostalCode", "class_laboratorio.html#ac63fd478a683ff10903e09bcce0b1a34", null ],
    [ "setAddress", "class_laboratorio.html#aad3d7a774f4eec49eb7d8f33a8483d03", null ],
    [ "setCity", "class_laboratorio.html#a1102946ca2a1e85a8e719e14d941afe1", null ],
    [ "setId", "class_laboratorio.html#a9f23aa743cf479084dc082b57cf89008", null ],
    [ "setLabName", "class_laboratorio.html#ad69e9d934f898392367e4b2028f78b00", null ],
    [ "setPostalCode", "class_laboratorio.html#a5ceb335191faccadd2461d89c273ffb1", null ],
    [ "operator<<", "class_laboratorio.html#a63ab9c7b5ebbb63f5aa25e344bbc9a22", null ],
    [ "operator==", "class_laboratorio.html#a172156dbac345c12d2ee6a99e03ba55a", null ],
    [ "m_address", "class_laboratorio.html#a009e3ab9f428d475654d4ccdafc365ac", null ],
    [ "m_city", "class_laboratorio.html#af23b9307ac6bf8fb1633d7f6dc39a0a1", null ],
    [ "m_id", "class_laboratorio.html#ab4335545f160db22b6be03bd4c9fe3a0", null ],
    [ "m_lab_name", "class_laboratorio.html#a1fe7b47325a928733f079408e2f8355b", null ],
    [ "m_postal_code", "class_laboratorio.html#add8a3e67616448a8e82ceb9dded72abf", null ]
];