var class_medi_express =
[
    [ "MediExpress", "class_medi_express.html#a459f195a308fec7b9690adefe7d6a8e1", null ],
    [ "MediExpress", "class_medi_express.html#a749cfbe6b5b56cae56158dd2afd12c8c", null ],
    [ "~MediExpress", "class_medi_express.html#a4f0ce2d811cc7d16c271346dd4c5bcf8", null ],
    [ "autoLinkMedications", "class_medi_express.html#a2592fd9cb8fb6d700dcd93b05cc155a8", null ],
    [ "buscarCompuesto", "class_medi_express.html#a7f1683ea69d35f56e00a5f37b5405a8e", null ],
    [ "buscarLab", "class_medi_express.html#aae9005b3b241c305177b00e9fb06651e", null ],
    [ "buscarLabCiudad", "class_medi_express.html#a5710513740aaa561bdc93b32b3fca55e", null ],
    [ "getMedicamSinLab", "class_medi_express.html#aa16c03a285555e4702cd2205b492d98c", null ],
    [ "loadLabFromCsv", "class_medi_express.html#a542b03937ee61412cced4f4368d0e083", null ],
    [ "loadMedicinesFromCsv", "class_medi_express.html#a6fbb0cf5e83118379b187faa27657172", null ],
    [ "suministrarMed", "class_medi_express.html#a10c0dec41b25a62023054ea486e8efe1", null ],
    [ "m_lab", "class_medi_express.html#a9823a455aa4c3ba727358a2fb7b7827d", null ],
    [ "m_med", "class_medi_express.html#a8913249e1c8d6d4886a7cbec69a521e1", null ]
];