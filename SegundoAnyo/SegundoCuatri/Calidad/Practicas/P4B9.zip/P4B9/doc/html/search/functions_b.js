var searchData=
[
  ['pamedicamento_0',['PaMedicamento',['../class_pa_medicamento.html#a9e582a7babc37dd7999c2df8d371e844',1,'PaMedicamento::PaMedicamento()'],['../class_pa_medicamento.html#a5b7ae106d5920bfce5ce94cb60a6c054',1,'PaMedicamento::PaMedicamento(int id_num, std::string_view id_alpha, std::string_view name)']]]
];
