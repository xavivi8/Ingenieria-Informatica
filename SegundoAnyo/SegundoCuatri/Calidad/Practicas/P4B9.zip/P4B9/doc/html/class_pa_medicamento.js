var class_pa_medicamento =
[
    [ "PaMedicamento", "class_pa_medicamento.html#a9e582a7babc37dd7999c2df8d371e844", null ],
    [ "PaMedicamento", "class_pa_medicamento.html#a5b7ae106d5920bfce5ce94cb60a6c054", null ],
    [ "~PaMedicamento", "class_pa_medicamento.html#a31687af923e1522e73ce624ade6435bc", null ],
    [ "getIdAlpha", "class_pa_medicamento.html#adfaf27829b85f290204ce888092e11af", null ],
    [ "getIdNum", "class_pa_medicamento.html#a1234486ad27dd251553ab5d75b266f87", null ],
    [ "getName", "class_pa_medicamento.html#a6cb0b9687d95f2fb5591a0b6d2bbf941", null ],
    [ "getServidoPor", "class_pa_medicamento.html#a3560aeb666f53986836de37a93bb8466", null ],
    [ "setIdAlpha", "class_pa_medicamento.html#a67d84d1d285e4fccccbf3b10ed5c4b32", null ],
    [ "setIdNum", "class_pa_medicamento.html#ab699a583c8fd3136326775ae758dd913", null ],
    [ "setName", "class_pa_medicamento.html#ae6dadd41c586ae27158fa94a414ede2a", null ],
    [ "setServidoPor", "class_pa_medicamento.html#abcc6a18b3481c64bff4bb458fdb3b44a", null ],
    [ "operator<", "class_pa_medicamento.html#ab9fdcfdeecdba52011d3013dc11ddc51", null ],
    [ "operator==", "class_pa_medicamento.html#ace249fa058ca67e4867ef79221de3649", null ],
    [ "m_id_alpha", "class_pa_medicamento.html#a2ab4a7d9b4a6cd6ffedd69faae092ba9", null ],
    [ "m_id_num", "class_pa_medicamento.html#a8d12d2ece27ad0cde3f8d63afe8f8ad7", null ],
    [ "m_name", "class_pa_medicamento.html#ad9c79faf360dbc5fcdf72b367e585a67", null ],
    [ "m_servidoPor", "class_pa_medicamento.html#af707867e6c06a602378313ad87709d00", null ]
];